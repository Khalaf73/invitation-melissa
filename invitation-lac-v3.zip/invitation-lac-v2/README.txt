INVITATION POUR MELISSA - VERSION 2

Ton lien Formspree est déjà intégré :
https://formspree.io/f/xeebdlwz

Pour tester :
1. Ouvre index.html dans ton navigateur.
2. Clique sur un bouton de réponse.
3. Tu devrais recevoir un mail Formspree.

Pour mettre en ligne :
- Dépose le dossier sur Vercel, Netlify ou GitHub Pages.
- Une fois le lien public obtenu, transforme-le en QR Code.

Fichiers :
- index.html : structure du site
- style.css : design et animations
- script.js : envoi de la réponse Formspree
- assets/invitation.png : affiche
